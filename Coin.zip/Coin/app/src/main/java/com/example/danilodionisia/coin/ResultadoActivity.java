package com.example.danilodionisia.coin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultadoActivity extends AppCompatActivity {

    private Button buttonVoltar;
    private ImageView imageResultado;
    private TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        buttonVoltar = findViewById(R.id.buttonVoltar);
        imageResultado = findViewById(R.id.imageResultado);
        textResultado = findViewById(R.id.textResultado);

        Bundle numero = getIntent().getExtras();
        int resultado = numero.getInt("numero");

        if (resultado == 0){
            imageResultado.setImageResource(R.drawable.moeda_cara);
            textResultado.setText("Cara");
        }else{
            imageResultado.setImageResource(R.drawable.moeda_coroa);
            textResultado.setText("Coroa");
        }

        buttonVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
